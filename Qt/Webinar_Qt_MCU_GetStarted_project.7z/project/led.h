#ifndef LED_H
#define LED_H

void green_led_switch_on();
void green_led_switch_off();

#endif // LED_H
